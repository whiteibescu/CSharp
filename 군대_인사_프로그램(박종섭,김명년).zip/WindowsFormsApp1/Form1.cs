﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 자식폼 호출
            Form2 frm = new Form2();
            // 자식폼 이벤트 호출하기
            frm.ChildFormEvent += Frm_ChildFormEvent;
            frm.ShowDialog();


        }

        private void Frm_ChildFormEvent(string str)
        {
            // 자식폼에서 델리게이트로 이벤트 발생 시키면 현재 함수
            // EventMethod 호출
            textBox1.Text = str.ToString();
        }

    }
}
