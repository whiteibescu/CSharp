﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.XPath;

namespace Unit_Management
{
    public partial class Form1 : Form
    {
        public static Form1 form1 = null;

        /*  public string Company_1_value { get; set; }*/
        TreeNode BattalianNode;
        TreeNode CompanyNode;
        TreeNode PlatoonNode;
        TreeNode SquadNode;

        Company_01 company1 = new Company_01();

        string EXODUS; // 출타자 문자열
        string DISPATCH; // 파견 문자열
        string OUTING; // 외출 
        string NAME; // 이름
        int UnitOut; // 출타 파견 외출 수
        
       /* public string RMcompany { get; set; }
        public string RMplatoon { get; set; }
        public string RMsquad { get; set; }
        public string RMname { get; set; }*/



        public Form1()
        {
            InitializeComponent();
            form1 = this;

        }



        private void TVUnit_AfterSelect(object sender, TreeViewEventArgs e)
        {
            this.Text = TVUnit.SelectedNode.Text;

        }

        public void Form1_Load(object sender, EventArgs e)
        {
            SoldierState soldierstate = new SoldierState();
            soldierstate.getstate += Soldierstate_getstate;
     
            // 대대 구성 TreeView로 출력 
            for (int i = 0; i < 1; i++)
            {
                if (i == 0)
                {
                    BattalianNode = new TreeNode();
                    BattalianNode.Text = "대한민국 해병대 비트캠프대대";
                    TVUnit.Nodes.Add(BattalianNode);
                }

                for (int j = 0; j < 5; j++)
                {
                    if (j == 0)
                    {
                        CompanyNode = new TreeNode();
                        CompanyNode.Text = "본부중대";
                        TVUnit.Nodes[i].Nodes.Add(CompanyNode);
                    }
                    else if (j == 1)
                    {
                        CompanyNode = new TreeNode();
                        CompanyNode.Text = "1중대";
                        TVUnit.Nodes[i].Nodes.Add(CompanyNode);
                    }
                    else if (j == 2)
                    {
                        CompanyNode = new TreeNode();
                        CompanyNode.Text = "2중대";
                        TVUnit.Nodes[i].Nodes.Add(CompanyNode);
                    }
                    else if (j == 3)
                    {
                        CompanyNode = new TreeNode();
                        CompanyNode.Text = "3중대";
                        TVUnit.Nodes[i].Nodes.Add(CompanyNode);
                    }
                    else if (j == 4)
                    {
                        CompanyNode = new TreeNode();
                        CompanyNode.Text = "화기중대";
                        TVUnit.Nodes[i].Nodes.Add(CompanyNode);
                    }
                    for (int p = 0; p < 5; p++)
                    {
                        if (j == 0)
                        {
                            if( p==0)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "중대장 이선미";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 1)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "보급";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 2)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "저격";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 3)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "취사";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 4)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "수송";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                        }
                        else if(j==1)
                        {
                            if(p==0)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "중대장 김경찬";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 1)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "1소대";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 2)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "2소대";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 3)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "3소대";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 4)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "60mm/HQ";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                        }
                        else if (j == 2)
                        {
                            if (p == 0)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "중대장 정푸른";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 1)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "1소대";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 2)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "2소대";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 3)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "3소대";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 4)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "60mm/HQ";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                        }
                        else if (j == 3)
                        {
                            if (p == 0)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "중대장 박재홍";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 1)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "1소대";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 2)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "2소대";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 3)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "3소대";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 4)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "60mm/HQ";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                        }
                        else if (j == 4)
                        {
                            if (p == 0)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "중대장 안정현";
                                
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 1)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "1소대";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 2)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "2소대";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 3)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "3소대";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                            else if (p == 4)
                            {
                                PlatoonNode = new TreeNode();
                                PlatoonNode.Text = "60mm/HQ";
                                TVUnit.Nodes[i].Nodes[j].Nodes.Add(PlatoonNode);
                            }
                        }
                        for (int s = 0; s < 3; s++)
                        {
                            if (j > 0 && p!=0)
                            {
                                if (s == 0)
                                {
                                    SquadNode = new TreeNode();
                                    SquadNode.Text = "1분대";
                                    TVUnit.Nodes[i].Nodes[j].Nodes[p].Nodes.Add(SquadNode);
                                }
                                else if (s == 1)
                                {
                                    SquadNode = new TreeNode();
                                    SquadNode.Text = "2분대";
                                    TVUnit.Nodes[i].Nodes[j].Nodes[p].Nodes.Add(SquadNode);
                                }
                                else if (s == 2)
                                {
                                    SquadNode = new TreeNode();
                                    SquadNode.Text = "3분대";
                                    TVUnit.Nodes[i].Nodes[j].Nodes[p].Nodes.Add(SquadNode);
                                }
                            }
                        }
                    }
                }
            }
            for (int o = 0; o < 4; o++)
            {
                if (o == 0)
                {
                    BattalianNode = new TreeNode();
                    BattalianNode.Text = "출타자";
                    TVUnit.Nodes.Add(BattalianNode);
                }
                else if (o == 1)
                {
                    BattalianNode = new TreeNode();
                    BattalianNode.Text = "파견";
                    TVUnit.Nodes.Add(BattalianNode);
                }
                else if (o == 2)
                {
                    BattalianNode = new TreeNode();
                    BattalianNode.Text = "외출";
                    TVUnit.Nodes.Add(BattalianNode);
                }
                else if (o == 3)
                {
                    BattalianNode = new TreeNode();
                    BattalianNode.Text = "후송";
                    TVUnit.Nodes.Add(BattalianNode);
                }
            }

        }

        // 트리노드 검색 메서드
        private TreeNode SearchNode(string SearchText, TreeNode StartNode)
        {
            TreeNode node = null;
            while (StartNode != null)
            {
                // 찾는 문자열을 찾아서 Start 노드에 넣어줌
                if (StartNode.Text.ToLower().Contains(SearchText.ToLower()))
                {
                    node = StartNode;
                    break;
                };

                // 없다면 다시 재귀해서 다시실해
                if (StartNode.Nodes.Count != 0)
                {
                    node = SearchNode(SearchText, StartNode.Nodes[0]);  //재귀함수 
                    if (node != null)
                    {
                        break;
                    };
                };
                StartNode = StartNode.NextNode;
            };
            return node;
        }

        // 출타자 파견 외출과 그에 대한 수를 가져올 때
        public void Soldierstate_getstate(string sname, string temp, int Otemp)
        {
            this.NAME = sname;
            if (temp == "출타자")
            {
                this.EXODUS = temp;
                this.UnitOut = Otemp;
                tbExodus.Text = UnitOut.ToString();
            }
            else if (temp == "파견")
            {
                this.DISPATCH = temp;
                this.UnitOut = Otemp;
                tbDispatch.Text = UnitOut.ToString();
            }
            else if (temp == "외출")
            {
                this.OUTING = temp;
                this.UnitOut = Otemp;
                tbOuting.Text = UnitOut.ToString();
            }
            ChangeSoldierState();
           
        }

        // 출타자 파견 외출에 추가
        public void ChangeSoldierState()
        {

            string changeName = this.NAME;
            TreeNode soldierNode = new TreeNode();

            if (this.EXODUS != null)
            {
                string changeExodus = this.EXODUS;
                BattalianNode = SearchNode(changeExodus, BattalianNode);
                soldierNode.Text = changeName;
                BattalianNode.Nodes.Add(soldierNode);
                this.EXODUS = null;
            }
            else if (this.DISPATCH != null)
            {
                string changeDispatch = this.DISPATCH;
                BattalianNode = SearchNode(changeDispatch, BattalianNode);
                soldierNode.Text = changeName;
                BattalianNode.Nodes.Add(soldierNode);
                this.DISPATCH = null;
            }
            else if (this.OUTING != null)
            {
                string changeOuting = this.OUTING;
                BattalianNode = SearchNode(changeOuting, BattalianNode);
                soldierNode.Text = changeName;
                BattalianNode.Nodes.Add(soldierNode);
                this.OUTING = null;
            }

        }

        // Company_1 Form에서 전달 받은 변수를 활용하여 TreeView에 출력
        private void Company_1_ChildFormEvent(string name, string platoon, string squad, string company, int num)
        {
            // 소대 분대 중대 구분지어서 입력을 받아야되는것
            // 중대별 노드 검색

            BattalianNode = TVUnit.Nodes[0];
            CompanyNode = SearchNode(company, BattalianNode);
            PlatoonNode = SearchNode(platoon, CompanyNode);
            SquadNode = SearchNode(squad, PlatoonNode);

            TreeNode soldierNode = new TreeNode();

            soldierNode.Text = name;
            SquadNode.Nodes.Add(soldierNode);

            tbTotal.Text = num.ToString();
        }

        // 클릭 시 각 중대 창 
        private void btnCompanyNum1_Click(object sender, EventArgs e)
        {

            Company_01 company_1 = new Company_01();

            company_1.SetCompanyName("1중대", "company_1.bin");
            company_1.setCaptainName("중대장 김경찬");
            company_1.ChildFormEvent += Company_1_ChildFormEvent;
            company_1.ShowDialog();
        }


        private void btnCompanyNum2_Click(object sender, EventArgs e)
        {
            Company_01 company_1 = new Company_01();
            company_1.SetCompanyName("2중대", "company_2.bin");
            company_1.setCaptainName("중대장 정푸른");
            company_1.ChildFormEvent += Company_1_ChildFormEvent;
            company_1.ShowDialog();

        }

        private void btnCompanyNum3_Click(object sender, EventArgs e)
        {
            Company_01 company_1 = new Company_01();
            company_1.SetCompanyName("3중대", "company_3.bin");
            company_1.setCaptainName("중대장 박재홍");
            company_1.ChildFormEvent += Company_1_ChildFormEvent;
            company_1.ShowDialog();
        }

        private void btnCompanyFA_Click(object sender, EventArgs e)
        {
            Company_01 company_1 = new Company_01();
            company_1.SetCompanyName("화기중대", "company_FA.bin");
            company_1.setCaptainName("중대장 안정현");
            company_1.ChildFormEvent += Company_1_ChildFormEvent;
            company_1.ShowDialog();
        }

        private void btnCompanyHQ_Click(object sender, EventArgs e)
        {
            Company_01 company_1 = new Company_01();
            company_1.SetCompanyName("본부중대", "company_HQ.bin");
            company_1.setCaptainName("중대장 이선미");
            company_1.ChildFormEvent += Company_1_ChildFormEvent;
            company_1.ShowDialog();

        }//(¶ㆍ₄ㆍ)¶

        // 노드 삭제
        private void button1_Click(object sender, EventArgs e)
        {
            TVUnit.Nodes.Remove(TVUnit.SelectedNode);
        }
    }
}
