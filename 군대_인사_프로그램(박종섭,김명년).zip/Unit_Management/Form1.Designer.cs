﻿namespace Unit_Management
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.TVUnit = new System.Windows.Forms.TreeView();
            this.tbTotal = new System.Windows.Forms.TextBox();
            this.TotalUnit = new System.Windows.Forms.Label();
            this.BattalionCommander = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbCompanyNum1 = new System.Windows.Forms.Label();
            this.lbCompanyNum2 = new System.Windows.Forms.Label();
            this.lbCompanyNum3 = new System.Windows.Forms.Label();
            this.lbFACompanyNum = new System.Windows.Forms.Label();
            this.lbHQCompanyNum = new System.Windows.Forms.Label();
            this.btnCompanyNum1 = new System.Windows.Forms.Button();
            this.btnCompanyNum2 = new System.Windows.Forms.Button();
            this.btnCompanyNum3 = new System.Windows.Forms.Button();
            this.btnCompanyFA = new System.Windows.Forms.Button();
            this.btnCompanyHQ = new System.Windows.Forms.Button();
            this.lbChoolta = new System.Windows.Forms.Label();
            this.lbDispatch = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbExodus = new System.Windows.Forms.TextBox();
            this.tbDispatch = new System.Windows.Forms.TextBox();
            this.tbOuting = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // TVUnit
            // 
            this.TVUnit.Location = new System.Drawing.Point(12, 57);
            this.TVUnit.Name = "TVUnit";
            this.TVUnit.Size = new System.Drawing.Size(417, 283);
            this.TVUnit.TabIndex = 0;
            this.TVUnit.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.TVUnit_AfterSelect);
            // 
            // tbTotal
            // 
            this.tbTotal.Location = new System.Drawing.Point(111, 346);
            this.tbTotal.Name = "tbTotal";
            this.tbTotal.Size = new System.Drawing.Size(108, 21);
            this.tbTotal.TabIndex = 1;
            // 
            // TotalUnit
            // 
            this.TotalUnit.AutoSize = true;
            this.TotalUnit.BackColor = System.Drawing.Color.Red;
            this.TotalUnit.Font = new System.Drawing.Font("휴먼엑스포", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.TotalUnit.ForeColor = System.Drawing.Color.Gold;
            this.TotalUnit.Location = new System.Drawing.Point(26, 346);
            this.TotalUnit.Name = "TotalUnit";
            this.TotalUnit.Size = new System.Drawing.Size(79, 21);
            this.TotalUnit.TabIndex = 2;
            this.TotalUnit.Text = "총 인원";
            // 
            // BattalionCommander
            // 
            this.BattalionCommander.AutoSize = true;
            this.BattalionCommander.BackColor = System.Drawing.Color.Red;
            this.BattalionCommander.Font = new System.Drawing.Font("휴먼엑스포", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.BattalionCommander.ForeColor = System.Drawing.Color.Gold;
            this.BattalionCommander.Location = new System.Drawing.Point(251, 346);
            this.BattalionCommander.Name = "BattalionCommander";
            this.BattalionCommander.Size = new System.Drawing.Size(90, 21);
            this.BattalionCommander.TabIndex = 3;
            this.BattalionCommander.Text = "교육대장";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Red;
            this.label3.Font = new System.Drawing.Font("휴먼엑스포", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.ForeColor = System.Drawing.Color.Gold;
            this.label3.Location = new System.Drawing.Point(23, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(472, 36);
            this.label3.TabIndex = 4;
            this.label3.Text = "대한민국 해병대 비트캠프대대";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // lbCompanyNum1
            // 
            this.lbCompanyNum1.AutoSize = true;
            this.lbCompanyNum1.BackColor = System.Drawing.Color.Red;
            this.lbCompanyNum1.Font = new System.Drawing.Font("휴먼엑스포", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbCompanyNum1.ForeColor = System.Drawing.Color.Gold;
            this.lbCompanyNum1.Location = new System.Drawing.Point(511, 104);
            this.lbCompanyNum1.Name = "lbCompanyNum1";
            this.lbCompanyNum1.Size = new System.Drawing.Size(91, 31);
            this.lbCompanyNum1.TabIndex = 5;
            this.lbCompanyNum1.Text = "1 중대";
            // 
            // lbCompanyNum2
            // 
            this.lbCompanyNum2.AutoSize = true;
            this.lbCompanyNum2.BackColor = System.Drawing.Color.Red;
            this.lbCompanyNum2.Font = new System.Drawing.Font("휴먼엑스포", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbCompanyNum2.ForeColor = System.Drawing.Color.Gold;
            this.lbCompanyNum2.Location = new System.Drawing.Point(503, 144);
            this.lbCompanyNum2.Name = "lbCompanyNum2";
            this.lbCompanyNum2.Size = new System.Drawing.Size(99, 31);
            this.lbCompanyNum2.TabIndex = 5;
            this.lbCompanyNum2.Text = "2 중대";
            // 
            // lbCompanyNum3
            // 
            this.lbCompanyNum3.AutoSize = true;
            this.lbCompanyNum3.BackColor = System.Drawing.Color.Red;
            this.lbCompanyNum3.Font = new System.Drawing.Font("휴먼엑스포", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbCompanyNum3.ForeColor = System.Drawing.Color.Gold;
            this.lbCompanyNum3.Location = new System.Drawing.Point(504, 187);
            this.lbCompanyNum3.Name = "lbCompanyNum3";
            this.lbCompanyNum3.Size = new System.Drawing.Size(98, 31);
            this.lbCompanyNum3.TabIndex = 5;
            this.lbCompanyNum3.Text = "3 중대";
            // 
            // lbFACompanyNum
            // 
            this.lbFACompanyNum.AutoSize = true;
            this.lbFACompanyNum.BackColor = System.Drawing.Color.Red;
            this.lbFACompanyNum.Font = new System.Drawing.Font("휴먼엑스포", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbFACompanyNum.ForeColor = System.Drawing.Color.Gold;
            this.lbFACompanyNum.Location = new System.Drawing.Point(465, 227);
            this.lbFACompanyNum.Name = "lbFACompanyNum";
            this.lbFACompanyNum.Size = new System.Drawing.Size(137, 31);
            this.lbFACompanyNum.TabIndex = 5;
            this.lbFACompanyNum.Text = "화기 중대";
            // 
            // lbHQCompanyNum
            // 
            this.lbHQCompanyNum.AutoSize = true;
            this.lbHQCompanyNum.BackColor = System.Drawing.Color.Red;
            this.lbHQCompanyNum.Font = new System.Drawing.Font("휴먼엑스포", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbHQCompanyNum.ForeColor = System.Drawing.Color.Gold;
            this.lbHQCompanyNum.Location = new System.Drawing.Point(465, 268);
            this.lbHQCompanyNum.Name = "lbHQCompanyNum";
            this.lbHQCompanyNum.Size = new System.Drawing.Size(137, 31);
            this.lbHQCompanyNum.TabIndex = 5;
            this.lbHQCompanyNum.Text = "본부 중대";
            // 
            // btnCompanyNum1
            // 
            this.btnCompanyNum1.Location = new System.Drawing.Point(618, 104);
            this.btnCompanyNum1.Name = "btnCompanyNum1";
            this.btnCompanyNum1.Size = new System.Drawing.Size(85, 31);
            this.btnCompanyNum1.TabIndex = 7;
            this.btnCompanyNum1.Text = "정보";
            this.btnCompanyNum1.UseVisualStyleBackColor = true;
            this.btnCompanyNum1.Click += new System.EventHandler(this.btnCompanyNum1_Click);
            // 
            // btnCompanyNum2
            // 
            this.btnCompanyNum2.Location = new System.Drawing.Point(618, 144);
            this.btnCompanyNum2.Name = "btnCompanyNum2";
            this.btnCompanyNum2.Size = new System.Drawing.Size(85, 31);
            this.btnCompanyNum2.TabIndex = 7;
            this.btnCompanyNum2.Text = "정보";
            this.btnCompanyNum2.UseVisualStyleBackColor = true;
            this.btnCompanyNum2.Click += new System.EventHandler(this.btnCompanyNum2_Click);
            // 
            // btnCompanyNum3
            // 
            this.btnCompanyNum3.Location = new System.Drawing.Point(618, 187);
            this.btnCompanyNum3.Name = "btnCompanyNum3";
            this.btnCompanyNum3.Size = new System.Drawing.Size(85, 31);
            this.btnCompanyNum3.TabIndex = 7;
            this.btnCompanyNum3.Text = "정보";
            this.btnCompanyNum3.UseVisualStyleBackColor = true;
            this.btnCompanyNum3.Click += new System.EventHandler(this.btnCompanyNum3_Click);
            // 
            // btnCompanyFA
            // 
            this.btnCompanyFA.Location = new System.Drawing.Point(618, 227);
            this.btnCompanyFA.Name = "btnCompanyFA";
            this.btnCompanyFA.Size = new System.Drawing.Size(85, 31);
            this.btnCompanyFA.TabIndex = 7;
            this.btnCompanyFA.Text = "정보";
            this.btnCompanyFA.UseVisualStyleBackColor = true;
            this.btnCompanyFA.Click += new System.EventHandler(this.btnCompanyFA_Click);
            // 
            // btnCompanyHQ
            // 
            this.btnCompanyHQ.Location = new System.Drawing.Point(618, 268);
            this.btnCompanyHQ.Name = "btnCompanyHQ";
            this.btnCompanyHQ.Size = new System.Drawing.Size(85, 31);
            this.btnCompanyHQ.TabIndex = 7;
            this.btnCompanyHQ.Text = "정보";
            this.btnCompanyHQ.UseVisualStyleBackColor = true;
            this.btnCompanyHQ.Click += new System.EventHandler(this.btnCompanyHQ_Click);
            // 
            // lbChoolta
            // 
            this.lbChoolta.AutoSize = true;
            this.lbChoolta.BackColor = System.Drawing.Color.Red;
            this.lbChoolta.Font = new System.Drawing.Font("휴먼엑스포", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbChoolta.ForeColor = System.Drawing.Color.Gold;
            this.lbChoolta.Location = new System.Drawing.Point(467, 328);
            this.lbChoolta.Name = "lbChoolta";
            this.lbChoolta.Size = new System.Drawing.Size(73, 22);
            this.lbChoolta.TabIndex = 8;
            this.lbChoolta.Text = "출타자";
            // 
            // lbDispatch
            // 
            this.lbDispatch.AutoSize = true;
            this.lbDispatch.BackColor = System.Drawing.Color.Red;
            this.lbDispatch.Font = new System.Drawing.Font("휴먼엑스포", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbDispatch.ForeColor = System.Drawing.Color.Gold;
            this.lbDispatch.Location = new System.Drawing.Point(467, 360);
            this.lbDispatch.Name = "lbDispatch";
            this.lbDispatch.Size = new System.Drawing.Size(70, 22);
            this.lbDispatch.TabIndex = 8;
            this.lbDispatch.Text = "파  견";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Red;
            this.label1.Font = new System.Drawing.Font("휴먼엑스포", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(467, 391);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 22);
            this.label1.TabIndex = 8;
            this.label1.Text = "외  출";
            // 
            // tbExodus
            // 
            this.tbExodus.Location = new System.Drawing.Point(563, 326);
            this.tbExodus.Name = "tbExodus";
            this.tbExodus.Size = new System.Drawing.Size(55, 21);
            this.tbExodus.TabIndex = 9;
            // 
            // tbDispatch
            // 
            this.tbDispatch.Location = new System.Drawing.Point(563, 360);
            this.tbDispatch.Name = "tbDispatch";
            this.tbDispatch.Size = new System.Drawing.Size(55, 21);
            this.tbDispatch.TabIndex = 9;
            // 
            // tbOuting
            // 
            this.tbOuting.Location = new System.Drawing.Point(563, 391);
            this.tbOuting.Name = "tbOuting";
            this.tbOuting.Size = new System.Drawing.Size(55, 21);
            this.tbOuting.TabIndex = 9;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(624, 324);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 10;
            this.button1.Text = "출타 인원 선택";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.Font = new System.Drawing.Font("휴먼엑스포", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(347, 346);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 21);
            this.label2.TabIndex = 3;
            this.label2.Text = "문상환";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(633, 375);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(155, 63);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Red;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbOuting);
            this.Controls.Add(this.tbDispatch);
            this.Controls.Add(this.tbExodus);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbDispatch);
            this.Controls.Add(this.lbChoolta);
            this.Controls.Add(this.btnCompanyHQ);
            this.Controls.Add(this.btnCompanyFA);
            this.Controls.Add(this.btnCompanyNum3);
            this.Controls.Add(this.btnCompanyNum2);
            this.Controls.Add(this.btnCompanyNum1);
            this.Controls.Add(this.lbHQCompanyNum);
            this.Controls.Add(this.lbFACompanyNum);
            this.Controls.Add(this.lbCompanyNum3);
            this.Controls.Add(this.lbCompanyNum2);
            this.Controls.Add(this.lbCompanyNum1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BattalionCommander);
            this.Controls.Add(this.TotalUnit);
            this.Controls.Add(this.tbTotal);
            this.Controls.Add(this.TVUnit);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox tbTotal;
        private System.Windows.Forms.Label TotalUnit;
        private System.Windows.Forms.Label BattalionCommander;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbCompanyNum1;
        private System.Windows.Forms.Label lbCompanyNum2;
        private System.Windows.Forms.Label lbCompanyNum3;
        private System.Windows.Forms.Label lbFACompanyNum;
        private System.Windows.Forms.Label lbHQCompanyNum;
        private System.Windows.Forms.Button btnCompanyNum1;
        private System.Windows.Forms.Button btnCompanyNum2;
        private System.Windows.Forms.Button btnCompanyNum3;
        private System.Windows.Forms.Button btnCompanyFA;
        private System.Windows.Forms.Button btnCompanyHQ;
        private System.Windows.Forms.Label lbChoolta;
        private System.Windows.Forms.Label lbDispatch;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TreeView TVUnit;
        private System.Windows.Forms.TextBox tbExodus;
        private System.Windows.Forms.TextBox tbDispatch;
        private System.Windows.Forms.TextBox tbOuting;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

