﻿namespace Unit_Management
{
    partial class Company_01
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Company_01));
            this.lb_1_Company = new System.Windows.Forms.Label();
            this.btnAddUnit = new System.Windows.Forms.Button();
            this.tbName = new System.Windows.Forms.TextBox();
            this.tbPlatoon = new System.Windows.Forms.TextBox();
            this.tbClass = new System.Windows.Forms.TextBox();
            this.tbSquad = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.chName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chClasses = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chPlatoon = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chSquad = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Remove = new System.Windows.Forms.Button();
            this.btn_Load = new System.Windows.Forms.Button();
            this.lbCaptain = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lb_1_Company
            // 
            this.lb_1_Company.AutoSize = true;
            this.lb_1_Company.BackColor = System.Drawing.Color.Red;
            this.lb_1_Company.Font = new System.Drawing.Font("휴먼엑스포", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lb_1_Company.ForeColor = System.Drawing.Color.Gold;
            this.lb_1_Company.Location = new System.Drawing.Point(32, 21);
            this.lb_1_Company.Name = "lb_1_Company";
            this.lb_1_Company.Size = new System.Drawing.Size(94, 36);
            this.lb_1_Company.TabIndex = 0;
            this.lb_1_Company.Text = "1중대";
            // 
            // btnAddUnit
            // 
            this.btnAddUnit.BackColor = System.Drawing.Color.Red;
            this.btnAddUnit.Font = new System.Drawing.Font("휴먼엑스포", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnAddUnit.ForeColor = System.Drawing.Color.Gold;
            this.btnAddUnit.Location = new System.Drawing.Point(618, 185);
            this.btnAddUnit.Name = "btnAddUnit";
            this.btnAddUnit.Size = new System.Drawing.Size(124, 103);
            this.btnAddUnit.TabIndex = 4;
            this.btnAddUnit.Text = "추 가";
            this.btnAddUnit.UseVisualStyleBackColor = false;
            this.btnAddUnit.Click += new System.EventHandler(this.btnAddUnit_Click);
            // 
            // tbName
            // 
            this.tbName.Location = new System.Drawing.Point(451, 167);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(138, 21);
            this.tbName.TabIndex = 0;
            // 
            // tbPlatoon
            // 
            this.tbPlatoon.Location = new System.Drawing.Point(451, 249);
            this.tbPlatoon.Name = "tbPlatoon";
            this.tbPlatoon.Size = new System.Drawing.Size(138, 21);
            this.tbPlatoon.TabIndex = 2;
            // 
            // tbClass
            // 
            this.tbClass.Location = new System.Drawing.Point(451, 206);
            this.tbClass.Name = "tbClass";
            this.tbClass.Size = new System.Drawing.Size(138, 21);
            this.tbClass.TabIndex = 1;
            // 
            // tbSquad
            // 
            this.tbSquad.Location = new System.Drawing.Point(451, 287);
            this.tbSquad.Name = "tbSquad";
            this.tbSquad.Size = new System.Drawing.Size(138, 21);
            this.tbSquad.TabIndex = 3;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chName,
            this.chClasses,
            this.chPlatoon,
            this.chSquad});
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(38, 74);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(333, 350);
            this.listView1.TabIndex = 11;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseDoubleClick);
            // 
            // chName
            // 
            this.chName.Text = "이름";
            this.chName.Width = 84;
            // 
            // chClasses
            // 
            this.chClasses.Text = "계급";
            this.chClasses.Width = 79;
            // 
            // chPlatoon
            // 
            this.chPlatoon.Text = "소대";
            this.chPlatoon.Width = 79;
            // 
            // chSquad
            // 
            this.chSquad.Text = "분대";
            this.chSquad.Width = 88;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.Font = new System.Drawing.Font("휴먼엑스포", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Location = new System.Drawing.Point(397, 167);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 21);
            this.label2.TabIndex = 12;
            this.label2.Text = "이름";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Red;
            this.label3.Font = new System.Drawing.Font("휴먼엑스포", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.ForeColor = System.Drawing.Color.Gold;
            this.label3.Location = new System.Drawing.Point(397, 206);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 21);
            this.label3.TabIndex = 12;
            this.label3.Text = "계급";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Red;
            this.label4.Font = new System.Drawing.Font("휴먼엑스포", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.ForeColor = System.Drawing.Color.Gold;
            this.label4.Location = new System.Drawing.Point(397, 249);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 21);
            this.label4.TabIndex = 12;
            this.label4.Text = "소대";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Red;
            this.label5.Font = new System.Drawing.Font("휴먼엑스포", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.ForeColor = System.Drawing.Color.Gold;
            this.label5.Location = new System.Drawing.Point(397, 287);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 21);
            this.label5.TabIndex = 12;
            this.label5.Text = "분대";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Red;
            this.label6.Font = new System.Drawing.Font("휴먼엑스포", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.ForeColor = System.Drawing.Color.Gold;
            this.label6.Location = new System.Drawing.Point(395, 116);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(241, 36);
            this.label6.TabIndex = 13;
            this.label6.Text = "추가 인원 사항";
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.Red;
            this.btn_Save.Font = new System.Drawing.Font("휴먼엑스포", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_Save.ForeColor = System.Drawing.Color.Gold;
            this.btn_Save.Location = new System.Drawing.Point(424, 327);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(140, 36);
            this.btn_Save.TabIndex = 14;
            this.btn_Save.Text = "저 장";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // btn_Remove
            // 
            this.btn_Remove.BackColor = System.Drawing.Color.Red;
            this.btn_Remove.Font = new System.Drawing.Font("휴먼엑스포", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_Remove.ForeColor = System.Drawing.Color.Gold;
            this.btn_Remove.Location = new System.Drawing.Point(581, 327);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(140, 78);
            this.btn_Remove.TabIndex = 14;
            this.btn_Remove.Text = "전 역";
            this.btn_Remove.UseVisualStyleBackColor = false;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // btn_Load
            // 
            this.btn_Load.BackColor = System.Drawing.Color.Red;
            this.btn_Load.Font = new System.Drawing.Font("휴먼엑스포", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_Load.ForeColor = System.Drawing.Color.Gold;
            this.btn_Load.Location = new System.Drawing.Point(424, 369);
            this.btn_Load.Name = "btn_Load";
            this.btn_Load.Size = new System.Drawing.Size(140, 36);
            this.btn_Load.TabIndex = 14;
            this.btn_Load.Text = "불러오기";
            this.btn_Load.UseVisualStyleBackColor = false;
            this.btn_Load.Click += new System.EventHandler(this.btn_Load_Click);
            // 
            // lbCaptain
            // 
            this.lbCaptain.AutoSize = true;
            this.lbCaptain.BackColor = System.Drawing.Color.Red;
            this.lbCaptain.Font = new System.Drawing.Font("휴먼엑스포", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbCaptain.ForeColor = System.Drawing.Color.Gold;
            this.lbCaptain.Location = new System.Drawing.Point(150, 21);
            this.lbCaptain.Name = "lbCaptain";
            this.lbCaptain.Size = new System.Drawing.Size(110, 36);
            this.lbCaptain.TabIndex = 15;
            this.lbCaptain.Text = "label1";
            // 
            // Company_01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(789, 447);
            this.Controls.Add(this.lbCaptain);
            this.Controls.Add(this.btn_Remove);
            this.Controls.Add(this.btn_Load);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.tbSquad);
            this.Controls.Add(this.tbClass);
            this.Controls.Add(this.tbPlatoon);
            this.Controls.Add(this.tbName);
            this.Controls.Add(this.btnAddUnit);
            this.Controls.Add(this.lb_1_Company);
            this.Name = "Company_01";
            this.Text = "Company_01";
            this.Load += new System.EventHandler(this.Company_01_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_1_Company;
        private System.Windows.Forms.Button btnAddUnit;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.TextBox tbPlatoon;
        private System.Windows.Forms.TextBox tbClass;
        private System.Windows.Forms.TextBox tbSquad;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader chName;
        private System.Windows.Forms.ColumnHeader chClasses;
        private System.Windows.Forms.ColumnHeader chPlatoon;
        private System.Windows.Forms.ColumnHeader chSquad;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_Remove;
        private System.Windows.Forms.Button btn_Load;
        private System.Windows.Forms.Label lbCaptain;
    }
}