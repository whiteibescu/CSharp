﻿namespace Unit_Management
{
    partial class SoldierState
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SoldierState));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdExodus = new System.Windows.Forms.RadioButton();
            this.rdDisPatch = new System.Windows.Forms.RadioButton();
            this.rdOuting = new System.Windows.Forms.RadioButton();
            this.btnModify = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnModify);
            this.groupBox1.Controls.Add(this.rdOuting);
            this.groupBox1.Controls.Add(this.rdDisPatch);
            this.groupBox1.Controls.Add(this.rdExodus);
            this.groupBox1.Font = new System.Drawing.Font("휴먼엑스포", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox1.Location = new System.Drawing.Point(28, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(506, 157);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "인원 상태";
            // 
            // rdExodus
            // 
            this.rdExodus.AutoSize = true;
            this.rdExodus.Location = new System.Drawing.Point(34, 47);
            this.rdExodus.Name = "rdExodus";
            this.rdExodus.Size = new System.Drawing.Size(88, 26);
            this.rdExodus.TabIndex = 0;
            this.rdExodus.TabStop = true;
            this.rdExodus.Text = "출타자";
            this.rdExodus.UseVisualStyleBackColor = true;
            // 
            // rdDisPatch
            // 
            this.rdDisPatch.AutoSize = true;
            this.rdDisPatch.Location = new System.Drawing.Point(206, 47);
            this.rdDisPatch.Name = "rdDisPatch";
            this.rdDisPatch.Size = new System.Drawing.Size(68, 26);
            this.rdDisPatch.TabIndex = 0;
            this.rdDisPatch.TabStop = true;
            this.rdDisPatch.Text = "파견";
            this.rdDisPatch.UseVisualStyleBackColor = true;
            // 
            // rdOuting
            // 
            this.rdOuting.AutoSize = true;
            this.rdOuting.Location = new System.Drawing.Point(378, 47);
            this.rdOuting.Name = "rdOuting";
            this.rdOuting.Size = new System.Drawing.Size(68, 26);
            this.rdOuting.TabIndex = 0;
            this.rdOuting.TabStop = true;
            this.rdOuting.Text = "외출";
            this.rdOuting.UseVisualStyleBackColor = true;
            // 
            // btnModify
            // 
            this.btnModify.Location = new System.Drawing.Point(141, 79);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(195, 45);
            this.btnModify.TabIndex = 3;
            this.btnModify.Text = "확 인";
            this.btnModify.UseVisualStyleBackColor = true;
            this.btnModify.Click += new System.EventHandler(this.btnModify_Click);
            // 
            // SoldierState
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(563, 189);
            this.Controls.Add(this.groupBox1);
            this.Name = "SoldierState";
            this.Text = "SoldierState";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdOuting;
        private System.Windows.Forms.RadioButton rdDisPatch;
        private System.Windows.Forms.RadioButton rdExodus;
        private System.Windows.Forms.Button btnModify;
    }
}