﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Unit_Management
{
    public partial class SoldierState : Form
    {
        public string SName { get; set; }
        static int Exodus = 0;
        static int Dispatch = 0;
        static int Outing = 0;

        public delegate void GetState(string sname, string temp, int Outing);
        public event GetState getstate;
        public SoldierState()
        {
            InitializeComponent();

        }
 
        public void setSName(string sname)
        {
            this.SName = sname;
            this.Text = this.SName;
        }


        private void btnModify_Click(object sender, EventArgs e)
        {
            string exodus = rdExodus.Text;
            string dispatch = rdDisPatch.Text;
            string outing = rdOuting.Text;
            string sname = this.Text;
            string temp = "";
            int Otemp = 0;
            getstate += Form1.form1.Soldierstate_getstate; // Form1안에의 추가 getstate 메서드를 추가해줌

            if (rdExodus.Checked == true)
            {
                temp = exodus;
                Exodus++;// 
                Otemp = Exodus;
                getstate(sname, temp, Otemp);// 호출
            }
            else if (rdDisPatch.Checked == true)
            {

                temp = dispatch;
                Dispatch++;
                Otemp = Dispatch;
               getstate(sname, temp, Otemp);
            }
            else if(rdOuting.Checked == true)
            {

                temp = outing;
                Outing++;
                Otemp = Outing;
               getstate(sname, temp, Otemp);
            }

            getstate -= Form1.form1.Soldierstate_getstate; // 메서드를 다시 끊어준다.
        }
    }
}
