﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Unit_Management
{
  
    public partial class Company_01 : Form
    {
        public string COMPANY { get; set; }
        public string FILE { get; set; }
        public string Captain { get; set; }

        static int num = 0;

        public delegate void ChildFormSendDataHandler(string name, string platoon, string squad, string company, int UnitCnt);
        public event ChildFormSendDataHandler ChildFormEvent;

        SoldierState soldierstate = new SoldierState();

        public Company_01()
        {
            InitializeComponent();
          
        }


        // 리스트뷰 아이템있는 수만큼 출력
        private void Company_01_Load(object sender, EventArgs e)
        {
           
            if (listView1.Items.Count != 0)
               for (int i = 0; i <= listView1.Items.Count; i++)
                {
                    listView1.Items[i].ToString();
                }
        }
        public void setCaptainName(string captain)
        {
            this.Captain = captain;
            lbCaptain.Text = this.Captain;
        }
        // 중대명과 파일저장이름
        public void SetCompanyName(string companyName, string file)
        {
            this.COMPANY = companyName;
            this.FILE = file;
            lb_1_Company.Text = this.COMPANY;
        }

        // 리스트 뷰에 인원추가와 이메서드에 쓰인 변수를 델리게이트 이벤트를 통해서 전달
        private void btnAddUnit_Click(object sender, EventArgs e)
        {

            string company = lb_1_Company.Text;
            string name = tbName.Text;
            string platoon = tbPlatoon.Text;
            string classes = tbClass.Text;
            string squad = tbSquad.Text;
            
            string[] strs = new string[] { name, classes, platoon, squad };


            listView1.Items.Add(new ListViewItem(strs));
            
            tbName.Clear();
            tbPlatoon.Clear();
            tbClass.Clear();
            tbSquad.Clear();

            num++;
            this.ChildFormEvent(name, platoon, squad, company, num);
        }

       
        //저장
        void Serializebinary()
        {
            FileStream fs = new FileStream(FILE, FileMode.Create);
            BinaryFormatter sf = new BinaryFormatter();

            List<ListViewItem> listItems = new List<ListViewItem>();
            foreach (ListViewItem lvi in listView1.Items)
            {
                listItems.Add(lvi);
            }
            sf.Serialize(fs, listItems);
            fs.Close();
        }

        //불러오기
        void DeserializeBinary()
        {
            
            FileStream fs = new FileStream(FILE, FileMode.Open, FileAccess.Read);
            BinaryFormatter sf = new BinaryFormatter();
            
            List<ListViewItem> listItems = sf.Deserialize(fs) as List<ListViewItem>;
            foreach (ListViewItem lvi in listItems)
            {
                listView1.Items.Add(lvi);
            }
            
            fs.Close();
        }

        // 더블 클릭시 인원 상태창을 띄움
        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            string sname = listView1.SelectedItems[0].SubItems[0].Text;
            soldierstate.setSName(sname);// SoldeierState폼에있는 SetSname 이름 문자열 넣어줌
            soldierstate.ShowDialog();
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            Serializebinary();
        }

        private void btn_Load_Click(object sender, EventArgs e)
        {
            DeserializeBinary();
        }

        // 삭제 기능
        private void btn_Remove_Click(object sender, EventArgs e)
        {
            bool selected = listView1.SelectedItems.Count > 0;
            if (selected == true)
            {
                ListViewItem lv = listView1.SelectedItems[0];
                listView1.Items.Remove(lv);
            }
            else
            {
                MessageBox.Show("전역을 시키지않겠다는 그 의지 좋습니다.");
                /*(" 눈앞이 깜깜합니다 더 복무하세요 ")*/

            }
        }
    }
}
